public class At13 {
   public static void main(String[] args) {
    
    int a=15, b=40;

    System.out.printf("%d, %d%n",a,b);

    a=55;
    b=77;
    System.out.printf("%d, %d%n",a,b);
   } 
}
