public class At06_1 {
  public static void main(String[] args) {
    double volume=0,raio=12,area=0,p=3.14;

    volume=(3/4)*p*(raio*raio*raio);
    area=4*p*(raio*raio);

    System.out.printf("%f, %f", volume, area);
  }  
}
