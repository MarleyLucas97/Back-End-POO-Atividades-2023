public class At02 {
    public static void main(String[] args) {
        
        int dia=14, mes=4, ano=1997;

        System.out.printf("%d / %d / %d", dia, mes, ano);
    }
}
