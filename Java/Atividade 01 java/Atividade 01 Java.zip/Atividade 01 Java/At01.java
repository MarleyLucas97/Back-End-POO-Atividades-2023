public class At01 {
    public static void main(String[] args) {
    
    char a='a';
    String frase="Ola, mundo!";
    int n=1;
    double n2=10.5;

    System.out.printf("%s%n%s%n%d%n%f%n",a,frase,n,n2);
    }
}