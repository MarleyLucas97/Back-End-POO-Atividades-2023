public class At04 {
    public static void main(String[] args) {
        int n1=2,n2=4,n3=6,n4=8,n5=10,cal, cal2;

        cal=n1+n2+n3+n4+n5;
        cal2=n1*n2*n3*n4*n5;

        System.out.printf("%d%n%d%n%d",cal,cal2,(cal+cal2)/2);
    }
}
