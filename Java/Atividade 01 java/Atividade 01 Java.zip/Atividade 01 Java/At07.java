public class At07 {
    public static void main(String[] args) {
        int temp=0, cel=30, fah=0;

        temp=cel*9;
        fah=(temp/5)+32;

        System.out.printf("%d fahrenheit.", fah);
    }
}
