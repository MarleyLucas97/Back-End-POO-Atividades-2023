<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>
    <form action="login.php" method="post">
        <label>NOME</label><br>
        <input type="text" name="nome" id=""><br><br>
        <label>SENHA</label><br>
        <input type="text" name="senha" id=""><br><br>
        <input type="submit" value="logar">
        <input type="submit" value="limpar">
    </form>
</body>
</html>